/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner kk= new Scanner(System.in);
		System.out.println(" Digite um número: ");
		double n1= kk.nextDouble();
		System.out.println(" Digite um número: ");
		double n2= kk.nextDouble();
		System.out.println(" Digite um número: ");
		double n3= kk.nextDouble();
		
		if(n1>n2 && n2>n3){
		    System.out.println(" A ordem crescente dos números é: "+n1 +n2 +n3);
		}else if(n2>n1 && n3>n1){
		     System.out.println(" A ordem crescente dos números é: "+n2 +n3 +n1);
		}else if (n1> n2 && n2<n3){
		     System.out.println(" A ordem crescente dos números é: "+n1 +n3 +n2);
		}else if(n2>n1 && n1>n3){
		    System.out.println(" A ordem crescente dos números é: "+n2 +n1 +n3);
		}else if(n3>n1 && n1>n2){
		    System.out.println(" A ordem crescente dos números é: "+n3 +n2 +n1);
		}else{
		    System.out.println(" A ordem crescente dos números é: "+n3 +n1 +n2);
		}
	}
}
