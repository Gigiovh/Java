/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner kk= new Scanner(System.in);
		System.out.println(" Digite um número: ");
		double n1= kk.nextDouble();
		System.out.println(" Digite um número: ");
		double n2= kk.nextDouble();
		System.out.println(" Digite um número: ");
		double n3= kk.nextDouble();
		
		if(n1>n2 && n2>n3){
		   double maior= n3;
		    double menor=n1;
		    double intermediário= n2;
		    
		}else if(n2>n1 && n3>n1){
		       double maior= n1;
		    double menor=n2;
		    double intermediário=n3;
		     
		}else if (n1> n2 && n2<n3){

		        double maior= n2;
		    double menor=n1;
		    double intermediário=n3;
		    
		}else if(n2>n1 && n1>n3){
		  
		       double maior= n3;
		    double menor=n2;
		    double intermediário=n1;
		}else if(n3>n1 && n1>n2){

		       double maior= n1;
		    double menor=n2;
		    double intermediário=n3;
		}else{
		    
		       double maior= n2;
		    double menor=n1;
		    double intermediário=n3;
		}
	}
}
