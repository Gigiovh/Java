/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

import java.util.Scanner;
public class Main
{ 
    public static void main (String[]args) {
    Scanner teste= new Scanner(System.in);
    System.out.println(" Escreva o nome da capital do Brasil ");
    String nm= teste.nextLine();
if(nm.equals("BRASÍLIA")||nm.equals("Brasília")){
    System.out.println("CORRETO");
}else{
    System.out.println("ERRADO");
}  
    
}
}