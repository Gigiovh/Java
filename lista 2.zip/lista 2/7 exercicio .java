/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner ft= new Scanner(System.in);
		System.out.println(" Digite a idade do nadador: ");
		int id= ft.nextInt();
		if (id>4 && id<8){
		    System.out.println(" Infantil A ");
		} else if(id>7&& id<12){
		    System.out.println(" Infantil B ");
		} else if(id>11&& id<14){
		    System.out.println(" Juvenil A ");
		} else if(id>13&& id<18){
		    System.out.println(" Juvenil B ");
		} else {
		    System.out.println(" Adultos  ");
		}
	}
}
