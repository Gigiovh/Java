/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

import java.util.Scanner;
public class Main
{
    public static void main(String[]args){
    Scanner meia= new Scanner(System.in);
    
    System.out.println(" Escreva seu nome: ");
    String nm= meia.nextLine();
    
    System.out.println(" Escreva seu gênero, sendo F ou f para feminino e M ou m para masculino: ");
    String gn= meia.nextLine();
    
    System.out.println(" Digite sua idade: ");
    int id= meia.nextInt();
    
    if(gn.equals("F") && 25>id ){
        System.out.println(" ACEITA ");
        
    }else if(gn.equals("f") && 25>id){
        System.out.println(" ACEITA ");
    }else{
        System.out.println(" NÃO ACEITA ");
    }
}
}

