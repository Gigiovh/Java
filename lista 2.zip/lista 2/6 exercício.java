/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner ft= new Scanner(System.in);
		System.out.println(" Digite o índice de poluição da empresa: ");
		double id= ft.nextDouble();
		if (id>0.04 && id<0.26){
		    System.out.println(" Aceitável");
		} else if(id>0.2&& id<0.4){
		    System.out.println(" As empresas do primeiro grupo devem parar suas atividades ");
		} else if(id>0.3&& id<0.5){
		    System.out.println("As empresas do primeiro e segundo devem parar suas atividades  ");
		} else {
		    System.out.println(" As empresas de todos os grupos devem parar suas atividades ");
		}
	}
}
