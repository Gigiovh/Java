/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[]args){
    Scanner meia= new Scanner(System.in);
    
    System.out.println(" Digite o valor do produto: ");
    double vl= meia.nextDouble();
    double p1=(vl/100)*45;
    double p2=(vl/100)*30;
    
    if(vl<20 ){
        System.out.println("O valor do produto é "+p1);
        
    }else{
        System.out.println("O valor do produto é "+p2);
    }
}
}
