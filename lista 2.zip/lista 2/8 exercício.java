/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner caneta= new Scanner(System.in);
	    
		System.out.println(" Digite um número: ");
		double n1= caneta.nextDouble();
		System.out.println(" Digite um número: ");
		double n2= caneta.nextDouble();
		
		double soma= n1+n2;
		
		if(soma>10){
		    System.out.println(" O resultado da soma é: "+soma);
		}else{
		}
		
	}
}
