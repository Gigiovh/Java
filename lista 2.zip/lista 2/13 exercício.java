/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner caneta= new Scanner(System.in);
	    
		System.out.println(" Digite um número: ");
		double n1= caneta.nextDouble();
		
		if(n1>20 ){
		    System.out.println(" É maior que 20 o número: "+n1);
		}else if(n1==20){
		    System.out.println(" É igual a 20 ");
		}else{
		    System.out.println(" É menor que 20 o número: "+n1);
		}
		
	}
}
