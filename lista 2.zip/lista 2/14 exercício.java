/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner tati= new Scanner(System.in);
		System.out.println(" Escreva seu nome: ");
		String nm= tati.nextLine();
		System.out.println(" Escreva a nota da prova 1: ");
		double p1= tati.nextDouble();
		System.out.println(" Escreva a nota da prova 2:  ");
		double p2= tati.nextDouble();
		
		double Média= (p1+p2)/2;
		
		System.out.println(" O aluno(a) de nome: "+nm);
		System.out.println("  Tirou na primeira prova e na segunda: "+p1 +p2);
		System.out.println(" A média final é: " +Média);
		
		
		if(Média>6){
		    System.out.println(" AP ");
		}else if(Média<4){
		    System.out.println(" RP ");
		}
		else{
		    System.out.println(" PF "); 
		}
		
	}
}
