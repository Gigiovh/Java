/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner kk= new Scanner(System.in);
		System.out.println(" Digite um número: ");
		double n1= kk.nextDouble();
		System.out.println(" Digite um número: ");
		double n2= kk.nextDouble();
		System.out.println(" Digite um número: ");
		double n3= kk.nextDouble();
		System.out.println(" Digite um número: ");
		double n4= kk.nextDouble();
		System.out.println(" Digite um número: ");
		double n5= kk.nextDouble();
		
		if(n1>n2 && n1>n3 && n1>n4 && n1>n5 && n2<n3 && n2<n4 && n2<n5){
		   double maior= n1;
		    double menor=n2;
		}
		    else if(n1>n2 && n1>n3 && n1>n4 && n1>n5 && n2>n3 && n3<n4 && n3<n5){
		   double maior= n1;
		    double menor=n3;
		    
		   }else  if(n1>n2 && n1>n3 && n1>n4 && n1>n5 && n4<n3 && n2>n4 && n4<n5){
		   double maior= n1;
		    double menor=n4;
		    
		   }else if(n1>n2 && n1>n3 && n1>n4 && n1>n5 && n5<n3 && n5<n4 && n2>n5){
		   double maior= n1;
		    double menor=n5;
		    
		}else if(n2>n1 && n2>n3&& n2>n4 && n2>n5 && n1<n3 && n1<n4 && n1<n5){
		       double maior= n2;
		    double menor=n1;
		    
		}else if(n2>n1 && n2>n3&& n2>n4 && n2>n5 && n3<n3 && n3<n4 && n3<n5){
		       double maior= n2;
		    double menor=n3;
		    
		}else if(n2>n1 && n2>n3&& n2>n4 && n2>n5 && n4<n3 && n1>n4 && n4<n5){
		       double maior= n2;
		    double menor=n4;
		    
		}else if(n2>n1 && n2>n3&& n2>n4 && n2>n5 && n5<n3 && n5<n4 && n1>n5){
		       double maior= n2;
		    double menor=n5;
		     
		}else if (n3> n2 && n3<n1 && n3>n4 && n3>n5 && n1<n2 && n1<n4 && n1<n5){

		        double maior= n3;
		    double menor=n1;
		    
		}else if (n3> n2 && n3<n1 && n3>n4 && n3>n5 && n1>n2 && n2<n4 && n2<n5){

		        double maior= n3;
		    double menor=n2;
		    
		}else if (n3> n2 && n3<n1 && n3>n4 && n3>n5 && n4<n2 && n1>n4 && n4<n5){

		        double maior= n3;
		    double menor=n4;
		    
		}else if (n3> n2 && n3<n1 && n3>n4 && n3>n5 && n5<n2 && n5<n4 && n1>n5){

		        double maior= n3;
		    double menor=n5;
		      
		    
		}else if(n4>n1 && n4>n3 && n4>n5 && n4>n2 && n1<n3 && n1<n2 && n1<n5){
		  
		       double maior= n4;
		    double menor=n1;
		    
		}else if(n4>n1 && n4>n3 && n4>n5 && n4>n2 && n2<n3 && n1>n2 && n2<n5){
		  
		       double maior= n4;
		    double menor=n2;
		    
		}else if(n4>n1 && n4>n3 && n4>n5 && n4>n2 && n1>n3 && n3<n2 && n3<n5){
		  
		       double maior= n4;
		    double menor=n3;
		    
		}else if(n4>n1 && n4>n3 && n4>n5 && n4>n2 && n5<n3 && n5<n2 && n1>n5){
		  
		       double maior= n4;
		    double menor=n5;
		    
		}else if(n5>n1 && n5>n2&& n5>n3&& n5>n4 && n1<n2 && n1<n3 && n1<n4){

		       double maior= n5;
		    double menor=n1;
		    
		}else if(n5>n1 && n5>n2&& n5>n3&& n5>n4 && n1>n2 && n2<n3 && n2<n4){

		       double maior= n5;
		    double menor=n2;
		    
		}else if(n5>n1 && n5>n2&& n5>n3&& n5>n4 && n3<n2 && n1>n3 && n3<n4){

		       double maior= n5;
		    double menor=n3;
		    
		}else{
		    
		       double maior= n5;
		    double menor=n4;
		}
	}
}
