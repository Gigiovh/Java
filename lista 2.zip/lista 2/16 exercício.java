/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

import java.util.Scanner;
public class Main
{
public static void main(String[]args){
Scanner gi=new Scanner(System.in);
System.out.println("Digite um número");
Double n1=gi.nextDouble();
System.out.println("Digite mais um número");
Double  n2=gi.nextDouble();
if(n1/n2==0){
System.out.println("O primeiro é divisível pelo segundo");
}else {
System.out.println("O primeiro não é divisível pelo segundo");
}
}
}