/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    
		System.out.println("Salário");
		
		Scanner numero= new Scanner(System.in);
		
		System.out.println(" Digite o código do funcionário: ");
		double C= numero.nextDouble();
		
		System.out.println(" Digite o número de horas trabalhadas: ");
		double N = numero.nextDouble();
		
		double sl=N*10;
		if(sl>50){
		    double E= sl-50;
		    double H= E*20;
		    double T=sl+ H;
		    System.out.println(" O salário total foi de "+T);
	          System.out.println(" O salário excedente foi: "+H);
		}else {
		    	System.out.println(" O salário total foi de "+sl);
	    System.out.println(" Não teve salário excedente");
		}
		    
	    
	}
	}
