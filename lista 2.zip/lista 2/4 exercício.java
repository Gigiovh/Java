/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner caneta= new Scanner(System.in);
	    
		System.out.println(" Digite um número: ");
		double n1= caneta.nextDouble();
		System.out.println(" Digite um número: ");
		double n2= caneta.nextDouble();
		System.out.println(" Digite um número: ");
		double n3= caneta.nextDouble();
		System.out.println(" Digite um número: ");
		double n4= caneta.nextDouble();
		
		double q1= n1*n1;
		double q2=n2*n2;
		double q3=n3*n3;
		double q4=n4*n4;
		
		if(q3>1000 || q3==1000){
		    System.out.println(" O quadrado do terceiro é: "+q3);
		}else{
		    System.out.println(" O quadrado dos respectivos números são: "+q1 +q2 +q3 +q4);
		}
		
	}
}
