/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scanner = new Scanner (System.in);
System.out.println("coloque qualquer número");
		double n1 = scanner.nextDouble();

		
if (n1 %5== 0)
{
System.out.println("o número é divisivel por 5");
}
else 
System.out.println("o número não é divisivel por 5");








}
}


