/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner kk= new Scanner(System.in);
		System.out.println(" Digite um número: ");
		double n1= kk.nextDouble();
		
		if(n1<16){
		   System.out.println(" Não eleitor ");
		}
		    else if(n1>=18 && n1<65 ){
		   System.out.println(" Eleitor obrigatório");
		    
		    
		}else{
		    
		       System.out.println(" Eleitor facultativo ");
		}
	}
}
