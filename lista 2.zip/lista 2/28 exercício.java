/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    
		System.out.println("Desconto");
		
		Scanner numero= new Scanner(System.in);
		
		System.out.println(" Digite o  seu salário: ");
		double n1 = numero.nextDouble();
		double d1=(n1/100)*20;
		double d2=(n1/100)*25;
		double d3=(n1/100)*30;
		
		if(n1<=600){
		    System.out.println(" Isento do desconto ");
		}else if (n1>600 && n1<=1200){
		    System.out.println(" Desconto de:  "+d1);
		    
		}else if (n1>1200 && n1<=2000){
		System.out.println(" Desconto de: "+d2);
	}else {
	    System.out.println(" Desconto de: "+d3);
	}
	    
	}
	}
